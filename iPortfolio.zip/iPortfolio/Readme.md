Technologies Used

HTML5
CSS3
JavaScript
bootstrap 
bootstrap-icons.css
Bootstrap boxicons
typed js

Contact

Email: rajnisharena@gmail.com
LinkedIn: https://www.linkedin.com/in/rajnish-sharma-front-end-developer/
Github: https://github.com/rajnisharena/
X : @Rajnish40783218